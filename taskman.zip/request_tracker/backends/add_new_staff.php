<?php
    include "../db/setup.php";
    $c = new crudOps();
    $staffname = $_GET["staffname"];
    $role = $_GET["role"];
    $dept = $_GET["dept"];
    $email = $_GET["email"];
    $phone = $_GET["phone"];
    $password = password_hash("defaultpassword",PASSWORD_DEFAULT);

    // get staff details
    $staff = explode(" ",$staffname);
    $fname = $staff[0];
    $mname = "";
    // print_r($_GET);
    if(sizeof($staff) == 2){
        $lname = $staff[1];
    }
    else if (sizeof($staff) > 2){
        $mname = $staff[1];
        $lname = $staff[2];
    }
    if($role == "00003"){
        $staffid = "handler".$fname;
    }
    else if($role == "00004"){
        $staffid = "suprvisor".$fname;
    }

    // add to users table
    $fields = array("userid","roleid","email","telephone","password");
    $values = array(array("$staffid","$role","$email","$phone","$password"));
    $rep1 = $c->addRecords($conn,$database,"users",$fields,$values);

    // add to staff table
    $fields = array("staffid","firstname","middlename","lastname","deptid");
    $values = array(array("$staffid","$fname","$mname","$lname","$dept"));
    $rep2 = $c->addRecords($conn,$database,"staff",$fields,$values);

    $return = "<ol>";
    if(strpos($rep1,"new record") !== false){
        if(strpos($rep2,"new record") !== false){
            $return .= "<li>$fname added sucessfully to database</li>";
        }
        else{
            $return .= "<li>Issues encountered adding record to Staff Table</li>";
        }
    }
    else{
        $return .= "<li>Issues encountered adding record to Users Table</li>";
    }
    $return .= "</ol>";
    echo $return;
    