<?php
    // include "../db/connect.php";
    session_start();
    include "../db/setup.php";
    $user_id = $_POST["user_id"];
    $user_passwd = $_POST["user_passwd"];
    $user_role = $_POST["user_role"];

    $c = new crudOps();

    $where = "userid = '$user_id'";
    $this_user = $c->readFilteredData($conn,$database,"users",$where);

    if($this_user->num_rows > 0){
        while($rows = $this_user->fetch_assoc()){
            if(password_verify($user_passwd,$rows["password"])){
                switch ($user_role){
                    case "admin":
                        $where2 = "staffid = '$user_id'";
                        $this_person = $c->readFilteredData($conn,$database,"staff",$where2);
                        if($this_person->num_rows > 0){
                            while($r = $this_person->fetch_assoc()){
                                $_SESSION["person"] = $r["firstname"]." ".$r["midlename"]." ".$r["lastname"];
                                $_SESSION["department"] = $r["deptid"];
                            }
                        }
                        header("Location:../dashboards/admin/");
                        break;
                    case "client":
                        header("Location:../dashboards/client/");
                        break;
                    case "handler":
                        header("Location:../dashboards/handler/");
                        break;
                    case "supervisor":
                        header("Location:../dashboards/supervisor/");
                        break;
                    default:
                        $_SESSION["invalid_login"] = "Please select your role";
                        header("Location:../");
                }
            }
            else{
                $_SESSION["invalid_login"] = "Wrong Password";
                header("Location:../");
            }
        }
    }
    else{
        $_SESSION["invalid_login"] = "No User ID or Email matched! Please type your user id ";
        header("Location:../");
    }
    
