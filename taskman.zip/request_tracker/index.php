<?php session_start(); include "db/setup.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>University Requests Tracker</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="bootstrap.min.css">
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
  .password-container {
      position: relative;
      max-width: 315px;
    }

    .password-container input[type="password"],
    .password-container input[type="text"] {
      width: 100%;
      padding: 10px 40px 10px 10px;
      font-size: 16px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-sizing: border-box;
    }

    .password-container .toggle-password {
      position: absolute;
      top: 50%;
      right: 10px;
      transform: translateY(-70%);
      cursor: pointer;
      font-size: 18px;
      color: #666;
    }

    .password-container .toggle-password:hover {
      color: #000;
    }
</style>
</head>
<body>
<div class="login-container row">
        <div class="left-panel col-lg-6 col-md-6 col-sm-12">
          <img src="undraw_certificate_71gt.svg" alt="Academic Progress Illustration" />
          <h2>Track All Your University Requests Easily</h2>
        </div>

        <div class="right-panel col-lg-6 col-md-6 col-sm-12 mt-sm-5 mt-lg-0 mt-md-0">


          <div class="form-container" id="logincon" >
            <div class="text-center mb-4 icons8">
                <img src="icons8-document-48.png" alt="Doc Icon">
              </div>
            <div class="tabs">
              <button class="active" onclick="login()">Login</button>
              <button onclick="Signup()">Sign Up</button>
            </div>
            <form action="backends/process_login.php" method="post">
              <p><?php if(isset($_SESSION["invalid_login"])){echo $_SESSION["invalid_login"];} ?></p>
              <input type="text" name = "user_id" placeholder="Email or User ID" required />
              <div class="password-container">
                <input type="password" class="passwordField" name = "user_passwd" placeholder="Password" required>
                <span class="togglePasswordBtn" style="position: absolute; right: 10px; top: 50%; transform: translateY(-70%); cursor: pointer;">
                  <i class="togglePasswordIcon far fa-eye-slash"></i>
                </span>
              </div>
              <select name = "user_role" required>
                <option>Select A Role</option>
                <option value="admin">Admin</option>
                <option value="student">Client</option>
                <option value="processor">Handler</option>
                <option value="admin">Supervisor</option>
              </select>
              <button type="submit" class="login-btn">Login</button>
              <a href="forgotten_password.php" class="fg-pass">Forgot Password?</a>
            </form>
            <div class="footer-links">
              <a href="privacy.php">Privacy policy</a>
              <a href="contact.php">Contact info</a>
            </div>
          </div>




          <div class="form-container" id="signincon" style="display:none;">
            <div class="text-center mb-4 icons8">
              <img src="icons8-document-48.png" alt="Doc Icon" />
            </div>

            <div class="tabs">
              <button onclick="login()">Login</button>
              <button class="active" onclick="Signup()">Sign Up</button>
            </div>

            <form>
              <input type="text" placeholder="Full Name" required />
              <input type="email" placeholder="Email" required />
              <div class="password-container">
                <input type="password" class="passwordField" placeholder="confirm Password" required>
                <span class="togglePasswordBtn" style="position: absolute; right: 10px; top: 50%; transform: translateY(-70%); cursor: pointer;">
                  <i class="togglePasswordIcon far fa-eye-slash"></i>
                </span>
              </div>
              <div class="password-container">
                <input type="password" class="passwordField" placeholder="Password" required>
                <span class="togglePasswordBtn" style="position: absolute; right: 10px; top: 50%; transform: translateY(-70%); cursor: pointer;">
                  <i class="togglePasswordIcon far fa-eye-slash"></i>
                </span>
              </div>
              
              <select required>
                <option value="">Select Role</option>
                <option value="student">Student</option>
                <option value="admin">Admin</option>
                <option value="processor">Processor</option>
              </select>

              <button type="submit" class="login-btn">Sign Up</button>
            </form>

            <div class="footer-links">
              <a href="privacy.php">Privacy policy</a>
              <a href="contact.php">Contact info</a>
            </div>
          </div>

        
        </div>
</div>
</body>

<script src="injex.js"></script>

</html>