<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Supervisor Dashboard - Request Tracker</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
    <script src='https://kit.fontawesome.com/a076d05399.js' crossorigin='anonymous'></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/bootstrap/bootstrap.min.css">
    <script src="../assets/bootstrap/bootstrap.min.js"></script>
    <style>
        body {
            background-color: #f9fafc;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .sidebar {
            min-height: 100vh;
            background-color: white;
            border-right: 1px solid #e0e0e0;
            padding: 20px 15px;
        }
        .sidebar .nav-link {
            font-weight: 500;
            font-size: 16px;
            color: #333;
            display: flex;
            align-items: center;
            gap: 10px;
            padding: 10px 15px;
            border-radius: 8px;
            transition: background 0.3s;
        }
        .sidebar .nav-link:hover,
        .sidebar .nav-link.active {
            background-color: #eaf1ff;
            color: #2a63e7;
        }
        .content {
            padding: 40px 30px;
        }
        .card-stats {
            padding: 20px;
            border-radius: 12px;
            background-color: white;
            box-shadow: 0 4px 12px rgba(0,0,0,0.05);
            text-align: center;
        }
        .card-stats h3 {
            font-size: 28px;
            font-weight: bold;
            color: #2a63e7;
        }
        table,th,td{
            font-size: 14px;
        }
        .card-stats p {
            font-size: 14px;
            color: #555;
        }
        .badge-completed {
            background-color: #2a63e7;
            color: white;
            border-radius: 8px;
            padding: 5px 12px;
            font-size: 14px;
        }
        .badge-pending {
            background-color: #f68c1f;
            color: white;
            border-radius: 8px;
            padding: 5px 12px;
            font-size: 14px;
        }
        .badge-processing {
            background-color: #17a2b8;
            color: white;
            border-radius: 8px;
            padding: 5px 12px;
            font-size: 14px;
        }
        .badge-message{
            font-family: monospace;
            font-size: 12px;
            font-weight: bold;
        }
        .completed{
            color: blue;
        }
        .supervisor-action{
            color: red;
        }
        .processing{
            color: green;
        }
    </style>
</head>
<body>

    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <nav class="col-md-2 sidebar">
                <div class="d-flex align-items-center mb-4">
                    <i class="fas fa-user-cog fs-3 text-primary me-2"></i>
                    <div>
                        <div class="fw-bold">Supervisor</div>
                        <small class="text-muted">Request Tracker</small>
                    </div>
                </div>
                <a href="#" class="nav-link active"><i class="fas fa-home"></i> Dashboard</a>
                <a href="#" class="nav-link"><i class="fas fa-file-alt"></i> All Requests</a>
                <a href="#" class="nav-link"><i class="fas fa-cog"></i> Settings</a>
                <a href="#" class="nav-link mt-4"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </nav>

            <!-- Main Content -->
            <main class="col-md-10 content">
                <h2 class="mb-4 fw-bold">Supervisor Dashboard</h2>

                <!-- Stats -->
                <div class="row mb-4">
                    <div class="col-md-4 mb-3">
                        <div class="card-stats">
                            <h3>150</h3>
                            <p>Total Requests</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-stats">
                            <h3>40</h3>
                            <p>Pending Requests</p>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3">
                        <div class="card-stats">
                            <h3>90</h3>
                            <p>Completed Requests</p>
                        </div>
                    </div>
                </div>

                <!-- Requests Table -->
                <h5 class="fw-bold mb-3">All Requests</h5>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Requester Name</th>
                                <th>Requester Type</th>
                                <th>ID Type</th>
                                <th>ID Number</th>
                                <th>Request Type</th>
                                <th>Email</th>
                                <th>Date Requested</th>
                                <th>Status/Current Processor</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1001</td>
                                <td>Osasu Iyekekpolor</td>
                                <td>Student</td>
                                <td>Student ID Card</td>
                                <td>STU1234</td>
                                <td>Transcript</td>
                                <td>osasu@uniben.edu</td>
                                <td>April 24, 2024</td>
                                <td>
                                    <span class="badge-completed">Completed</span><br>
                                    <span class="badge-message completed">Transcript dispatched</span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-primary me-1">View</button>  
                                </td>
                            </tr>
                            <tr>
                                <td>1002</td>
                                <td>Kingsley Ehiaghe</td>
                                <td>Contractor</td>
                                <td>Driver's Licence</td>
                                <td>BEN1214AC</td>
                                <td>Submission of Proforma Invoice</td>
                                <td>kingsley@uniben.edu</td>
                                <td>April 26, 2024</td>
                                <td>
                                    <span class="badge-pending">Pending</span><br>
                                    <span class="badge-message supervisor-action">Supervisor Action Required</span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-primary me-1">View</button>
                                    
                                </td>
                            </tr>
                            <tr>
                                <td>1003</td>
                                <td>Jennifer Ogbemudia</td>
                                <td>Staff</td>
                                <td>National ID</td>
                                <td>11025414781</td>
                                <td>Request for Annual Leave</td>
                                <td>jennifer@uniben.edu</td>
                                <td>April 28, 2024</td>
                                <td>
                                    <span class="badge-processing">Processing</span><br>
                                    <span class="badge-message processing">Accounts & Payrol Desk</span>
                                </td>
                                <td>
                                    <button class="btn btn-sm btn-primary me-1">View</button>
                                   
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </main>
        </div>
    </div>

    <!-- Bootstrap JS + FontAwesome -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>

</body>
</html>
