<?php
    $conn = new mysqli("localhost","root","");
    $database = "tracker_db";
?>